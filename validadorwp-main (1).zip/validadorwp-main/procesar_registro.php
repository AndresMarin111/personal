
<?php
require_once 'vendor/autoload.php';

use Twilio\Rest\Client;

$sid = 'ACc816e9b462261c20fa83e6d0481cdd01';  // Tu SID de Twilio
$token = 'AuthToken';  // Tu Token de Twilio
$client = new Client($sid, $token);

$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$codigo = rand(1000, 9999);

$message = $client->messages->create(
    $telefono, 
    [
        'from' => 'NUMERO_DE_TWILIO',
        'body' => "Tu código de verificación es: $codigo"
    ]
);

session_start();
$_SESSION['codigo'] = $codigo;

header('Location: verificar_codigo.php');
exit();
?>

<?php
// Update the path below to your autoload.php,
// see https://getcomposer.org/doc/01-basic-usage.md
require_once '/path/to/vendor/autoload.php';
use Twilio\Rest\Client;

$sid    = "ACc816e9b462261c20fa83e6d0481cdd01";
$token  = "[AuthToken]";
$twilio = new Client($sid, $token);

$verification = $twilio->verify->v2->services("VAc73e2ad72b70d4dadffa2fc3477dd3c6")
                                   ->verifications
                                   ->create("+573182453406", "sms");

print($verification->sid);