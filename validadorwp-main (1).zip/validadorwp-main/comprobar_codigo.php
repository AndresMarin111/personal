
<?php
session_start();

$codigo_usuario = $_POST['codigo'];
$codigo_real = $_SESSION['codigo'];

if ($codigo_usuario == $codigo_real) {
    echo "Código verificado correctamente.";
    // Aquí podrías redirigir o realizar otras operaciones necesarias
} else {
    echo "Código incorrecto. Intente de nuevo.";
}
?>
