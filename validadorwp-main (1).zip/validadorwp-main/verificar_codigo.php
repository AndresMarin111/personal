
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Verificar Código</title>
</head>
<body>
    <h1>Verificar Código</h1>
    <form method="post" action="comprobar_codigo.php">
        <label for="codigo">Código de Verificación:</label>
        <input type="text" id="codigo" name="codigo" required><br><br>

        <input type="submit" value="Verificar Código">
    </form>
</body>
</html>
