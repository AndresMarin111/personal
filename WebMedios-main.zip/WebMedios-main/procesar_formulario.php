<?php
header('Content-Type: text/html; charset=utf-8');
require('fpdf/fpdf.php'); // Incluye la biblioteca FPDF

// Verifica si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoge los datos del formulario
    $fecha = $_POST["fecha"];
    $ciudad_solicitud = $_POST["ciudad_solicitud"];
    $solicitante = $_POST["solicitante"];
    $solicitud_credito = $_POST["solicitud_credito"];
    $primer_nombre = $_POST["primer_nombre"];
    $segundo_nombre = $_POST["segundo_nombre"];
    $primer_apellido = $_POST["primer_apellido"];
    $segundo_apellido = $_POST["segundo_apellido"];
    $tipo_identificacion = $_POST["tipo_identificacion"];
    $lugar_expedicion = $_POST["lugar_expedicion"];
    $fecha_expedicion = $_POST["fecha_expedicion"];
    $Lugar_nacimiento = $_POST["Lugar_nacimiento"];
    $Fecha_nacimiento = $_POST["Fecha_nacimiento"];
    $Estado_civil = $_POST["Estado_civil"];
    $Direccion_residencia = $_POST["Direccion_residencia"];
    $Ciudad_residencia = $_POST["Ciudad_residencia"];
    $Numero_celular = $_POST["Telefono_celular"];
    $Numero_fijo = $_POST["Telefono_fijo"];
    $Correo_electronico = $_POST["Correo_electronico"];
    $Nombre_conyuge = $_POST["Nombre_conyuge"];
    $Tipo_identificacion_conyuge = $_POST["Tipo_identificacion_conyuge"];
    $Numero_identificacion_conyuge = $_POST["Numero_identificacion_conyuge"];
    $Telefono_conyuge = $_POST["Telefono_conyuge"];

    $Codeudor_primer_nombre = $_POST["Codeudor_primer_nombre"];
    $Codeudor_segundo_nombre = $_POST["Codeudor_segundo_nombre"];
    $Codeudor_primer_apellido = $_POST["Codeudor_primer_apellido"];
    $Codeudor_segundo_apellido = $_POST["Codeudor_segundo_apellido"];

    $ocupacion = $_POST["ocupacion"];


    $descripcion_actividad = $_POST["descripcion_actividad"];
    $direccion_oficina = $_POST["direccion_oficina"];
    $ciudad_oficina = $_POST["ciudad_oficina"];
    $telefono_oficina = $_POST["telefono_oficina"];
    $empresa_trabajo = $_POST["empresa_trabajo"];
    $nit_empresa = $_POST["nit_empresa"];
    $direccion_empresa = $_POST["direccion_empresa"];
    $telefono_empresa = $_POST["telefono_empresa"];
    $cargo = $_POST["cargo"];
    $tipo_contrato = $_POST["tipo_contrato"];
    $tiempo_actividad = $_POST["tiempo_actividad"];
   // $nombre_codeudor = $_POST["nombre_codeudor"];
    $tipo_identificacion_codeudor = $_POST["tipo_identificacion_codeudor"];
    $lugar_expedicion_codeudor = $_POST["lugar_expedicion_codeudor"];
    $fecha_expedicion_codeudor = $_POST["fecha_expedicion_codeudor"];
    $direccion_residencia_codeudor = $_POST["direccion_residencia_codeudor"];
    $ciudad_residencia_codeudor = $_POST["ciudad_residencia_codeudor"];
    $telefono_fijo_codeudor = $_POST["telefono_fijo_codeudor"];
    $telefono_celular_codeudor = $_POST["telefono_celular_codeudor"];
    $monto_solicitado = $_POST["monto_solicitado"];
    $campana = $_POST["campana"];
    $oficina_desembolso = $_POST["oficina_desembolso"];
    $garantia = $_POST["garantia"];
    $tipo_bien = $_POST["tipo_bien"];
    $direccion_bien = $_POST["direccion_bien"];
    $matricula = $_POST["matricula"];
    $valor_comercial = $_POST["valor_comercial"];
    $hipotecado = $_POST["hipotecado"];
    $vehiculo = $_POST["vehiculo"];
    $modelo = $_POST["modelo"];
    $placa = $_POST["placa"];
    $valor_comercial_vehiculo = $_POST["valor_comercial_vehiculo"];
    $pignorado = $_POST["pignorado"];
    $nombre_referencia1 = $_POST["nombre_referencia1"];
    $celular_referencia1 = $_POST["celular_referencia1"];
    $ciudad_referencia1 = $_POST["ciudad_referencia1"];
    $departamento_referencia1 = $_POST["departamento_referencia1"];
    $nombre_referencia2 = $_POST["nombre_referencia2"];
    $celular_referencia2 = $_POST["celular_referencia2"];
    $ciudad_referencia2 = $_POST["ciudad_referencia2"];
    $departamento_referencia2 = $_POST["departamento_referencia2"];

    // Crear el objeto FPDF
    $pdf = new FPDF();
    $pdf->AddPage();

    // Agregar el contenido del PDF
    $pdf->SetFillColor(0, 255, 0);
    $pdf->SetFont('Arial', 'B', 20);
    $pdf->Image('img/medios.JPG' , 10 ,5, 60 , 20,'jpg');
    $pdf->Cell(0, 10, 'Formulario de Solicitud de Credito', 0, 1, 'R');

    // Agregar los datos del formulario al PDF
    // pendiente que el ancho maximo de documento va ser 190.
    
    $pdf->SetTextColor (0,0,0);
    $pdf->SetDrawColor (0,0,0);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Ln(5);
   
    $pdf->Cell(50, 10, "Fecha: $fecha ", 1, 0, 'L', false );
    $pdf->Cell(140, 10, "Ciudad de Solicitud: $ciudad_solicitud", 1, 1, 'L', false);
    $pdf->Ln(0);
    $pdf->Cell(190, 10, "1. SOLICITUD DE PRODUCTO Y SERVICIO", 0, 1, 'C');
    $pdf->Ln(0);
    $pdf->Cell(50, 10, "Solicitante: $solicitante", 1, 0, 'L', false);
    $pdf->Cell(140, 10, "Solicitud de Credito: $solicitud_credito", 1, 1);

    //INFORMACION BASICA
    $pdf->Cell(190, 10, "2. INFORMACION BASICA", 0, 1, 'C');
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Primer Nombre: $primer_nombre", 1, 0);
    $pdf->Cell(95, 10, "Segundo Nombre: $segundo_nombre", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Primer Apellido: $primer_apellido", 1, 0);
    $pdf->Cell(95, 10, "Segundo Apellido: $segundo_apellido", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(50, 10, "Tipo de Identificacion: $tipo_identificacion", 1, 0);
    $pdf->Cell(66, 10, "Lugar de Expedicion: $lugar_expedicion", 1, 0);
    $pdf->Cell(74, 10, "Fecha de Expedicion: $fecha_expedicion", 1, 1);
   
    $pdf->Cell(63, 10, "Fecha de Nacimiento: $Fecha_nacimiento", 1, 0);
    $pdf->Cell(87, 10, "Lugar de Nacimiento: $Lugar_nacimiento", 1, 0);
    $pdf->Cell(40, 10, "Estado Civil: $Estado_civil", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Direccion de Residencia : $Direccion_residencia", 1, 0);
    $pdf->Cell(95, 10, "Ciudad de residencia: $Ciudad_residencia", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Numero fijo: $Numero_fijo", 1, 0);
    $pdf->Cell(95, 10, "Numero celular: $Numero_celular", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(190, 10, "Correo electronico: $Correo_electronico", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(190, 10, "Nombre Completo conyuge: $Nombre_conyuge", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(50, 10, "Tipo de Identificacion: $Tipo_identificacion_conyuge", 1, 0);
    $pdf->Cell(66, 10, "Numero de identificacion: $Numero_identificacion_conyuge", 1, 0);
    $pdf->Cell(74, 10, "Telefono Celular: $Telefono_conyuge", 1, 1);

    //ACTIVIDAD ECONOMICA
    $pdf->Cell(190, 10, "3. ACTIVIDAD ECONOMICA", 0, 1, 'C');
    $pdf->Ln(0);
    $pdf->Cell(190, 10, "Ocupacion: $ocupacion", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Descripcion de la Actividad: $descripcion_actividad", 1, 0);
    $pdf->Cell(95, 10, "Direccion de Oficina: $direccion_oficina", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Ciudad de Oficina: $ciudad_oficina", 1, 0);
    $pdf->Cell(95, 10, "Telefono de Oficina: $telefono_oficina", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(190, 10, "Empresa donde Trabaja: $empresa_trabajo", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "NIT de la Empresa: $nit_empresa", 1, 0);
    $pdf->Cell(95, 10, "Direccion de la Empresa: $direccion_empresa", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Telefono de la Empresa: $telefono_empresa", 1, 0);
    $pdf->Cell(95, 10, "Cargo: $cargo", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Tipo de Contrato: $tipo_contrato", 1, 0);
    $pdf->Cell(95, 10, "Tiempo en la Actividad: $tiempo_actividad", 1, 1);
     
    //datos codeudor
    $pdf->Cell(190, 10, "4. INFORMACION DEL COUDEUDOR O APONDERADO", 0, 1, 'C');
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Primer Nombre: $Codeudor_primer_nombre", 1, 0);
    $pdf->Cell(95, 10, "Segundo Nombre: $Codeudor_segundo_nombre", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Primer Apellido: $Codeudor_primer_apellido", 1, 0);
    $pdf->Cell(95, 10, "Segundo Apellido: $Codeudor_segundo_apellido", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(50, 10, "Tipo de Identificacion: $tipo_identificacion_codeudor", 1, 0);
    $pdf->Cell(66, 10, "Lugar de Expedicion: $lugar_expedicion_codeudor", 1, 0);
    $pdf->Cell(74, 10, "Fecha de Expedicion: $fecha_expedicion_codeudor", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Direccion de Residencia: $direccion_residencia_codeudor", 1, 0);
    $pdf->Cell(95, 10, "Ciudad de Residencia: $ciudad_residencia_codeudor", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Telefono Fijo: $telefono_fijo_codeudor", 1, 0);
    $pdf->Cell(95, 10, "Telefono Celular: $telefono_celular_codeudor", 1, 1);


    //condiciones de credito
    $pdf->Cell(190, 10, "5. CONDICIONES DE CREDITO", 0, 1, 'C');
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Monto Solicitado: $monto_solicitado", 1, 0);
    $pdf->Cell(95, 10, "Campaña: $campana", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Oficina de Desembolso: $oficina_desembolso", 1, 0);
    $pdf->Cell(95, 10, "Garantia: $garantia", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(50, 10, "Tipo de Bien: $tipo_bien", 1, 0);
    $pdf->Cell(70, 10, "Direccion del Bien: $direccion_bien", 1, 0);
    $pdf->Cell(70, 10, "Matricula: $matricula", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Valor Comercial: $valor_comercial", 1, 0);
    $pdf->Cell(95, 10, "Hipotecado: $hipotecado", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(90, 10, "Vehiculo: $vehiculo", 1, 0);
    $pdf->Cell(50, 10, "Modelo: $modelo", 1, 0);
    $pdf->Cell( 50, 10, "Placa: $placa", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(140, 10, "Valor Comercial del Vehiculo: $valor_comercial_vehiculo", 1, 0);
    $pdf->Cell(50, 10, "Pignorado: $pignorado", 1, 1);
    $pdf->Ln(0);
    $pdf->Cell(190, 10, "6. REFERENCIAS", 0, 1, 'C');
    $pdf->Ln(0);
    $pdf->Cell(95, 10, "Nombre Referencia 1: $nombre_referencia1", 1, 0);
    $pdf->Cell(95, 10, "Celular Referencia 1: $celular_referencia1", 1, 1);
    $pdf->Cell(95, 10, "Ciudad Referencia 1: $ciudad_referencia1", 1, 0);
    $pdf->Cell(95, 10, "Departamento Referencia 1: $departamento_referencia1", 1, 1);
    $pdf->Cell(95, 10, "Nombre Referencia 2: $nombre_referencia2", 1, 0);
    $pdf->Cell(95, 10, "Celular Referencia 2: $celular_referencia2", 1, 1);
    $pdf->Cell(95, 10, "Ciudad Referencia 2: $ciudad_referencia2", 1, 0);
    $pdf->Cell(95, 10, "Departamento Referencia 2: $departamento_referencia2", 1, 1);

    //referencias




    /* $pdf->Ln(0);
  
   
   
    $pdf->Cell(0, 10, "Monto Solicitado: $monto_solicitado", 0, 1);
    $pdf->Cell(0, 10, "Campaña: $campana", 0, 1);
    $pdf->Cell(0, 10, "Oficina de Desembolso: $oficina_desembolso", 0, 1);
    $pdf->Cell(0, 10, "Garantía: $garantia", 0, 1);
    $pdf->Cell(0, 10, "Tipo de Bien: $tipo_bien", 0, 1);
    $pdf->Cell(0, 10, "Dirección del Bien: $direccion_bien", 0, 1);
    $pdf->Cell(0, 10, "Matrícula: $matricula", 0, 1);
    $pdf->Cell(0, 10, "Valor Comercial: $valor_comercial", 0, 1);
    $pdf->Cell(0, 10, "Hipotecado: $hipotecado", 0, 1);
    $pdf->Cell(0, 10, "Vehículo: $vehiculo", 0, 1);
    $pdf->Cell(0, 10, "Modelo: $modelo", 0, 1);
    $pdf->Cell(0, 10, "Placa: $placa", 0, 1);
    $pdf->Cell(0, 10, "Valor Comercial del Vehículo: $valor_comercial_vehiculo", 0, 1);
    $pdf->Cell(0, 10, "Pignorado: $pignorado", 0, 1);
    $pdf->Cell(0, 10, "Nombre Referencia 1: $nombre_referencia1", 0, 1);
    $pdf->Cell(0, 10, "Celular Referencia 1: $celular_referencia1", 0, 1);
    $pdf->Cell(0, 10, "Ciudad Referencia 1: $ciudad_referencia1", 0, 1);
    $pdf->Cell(0, 10, "Departamento Referencia 1: $departamento_referencia1", 0, 1);
    $pdf->Cell(0, 10, "Nombre Referencia 2: $nombre_referencia2", 0, 1);
    $pdf->Cell(0, 10, "Celular Referencia 2: $celular_referencia2", 0, 1);
    $pdf->Cell(0, 10, "Ciudad Referencia 2: $ciudad_referencia2", 0, 1);
    $pdf->Cell(0, 10, "Departamento Referencia 2: $departamento_referencia2", 0, 1);
*/
    // Definir el nombre del archivo PDF
    $filename = 'formulario_solicitud_credito.pdf';

    // Descargar el PDF
    $pdf->Output('D', $filename);
    exit;
} else {
    // Si se intenta acceder directamente a este script sin enviar datos por POST, redirigir a la página del formulario
    header("Location: formulario.php");
    exit;
}
?>
