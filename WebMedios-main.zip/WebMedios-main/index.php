<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Solicitud de Crédito</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script>
        $(function() {
            $("#fecha_expedicion").datepicker({
                dateFormat: 'yy-mm-dd',
                changeYear: true,
                changeMonth: true,
                yearRange: "-100:+0" // Permite seleccionar años desde hace 100 años hasta el año actual
            });
        });
    </script>
    <script>
        $(function() {
            $("#Fecha_nacimiento").datepicker({
                dateFormat: 'yy-mm-dd',
                changeYear: true,
                changeMonth: true,
                yearRange: "-100:+0" // Permite seleccionar años desde hace 100 años hasta el año actual
            });
        });
    </script>
</head>
<body>



<form action="procesar_formulario.php" method="POST">
<h2>Formulario de Solicitud de Crédito</h2>
<div>
    <label for="fecha">Fecha:</label>
    <input type="text" name="fecha" value="<?php echo date('Y-m-d'); ?>" readonly>

    <label for="ciudad_solicitud">Ciudad de Solicitud:</label>
    <input type="text" name="ciudad_solicitud"><br><br>

    <label for="solicitante">Solicitante:</label>
    <select name="solicitante">
        <option value="cliente">Cliente</option>
        <option value="cliente_firma">Cliente con Firma a Ruego</option>
        <option value="apoderado">Cliente con Apoderado</option>
    </select><br><br>
    </div>
    <label for="solicitud_credito">Solicitud de Crédito:</label>
    <select name="solicitud_credito">
        <option value="educativo">Educativo</option>
        <option value="renovacion">Renovación</option>
        <option value="otro">Otro</option>
    </select><br><br>

    <label>Datos Personales del Solicitante:</label><br>

    <label for="primer_nombre">Primer Nombre:</label>
    <input type="text" name="primer_nombre"><br><br>

    <label for="segundo_nombre">Segundo Nombre:</label>
    <input type="text" name="segundo_nombre"><br><br>

    <label for="primer_apellido">Primer Apellido:</label>
    <input type="text" name="primer_apellido"><br><br>

    <label for="segundo_apellido">Segundo Apellido:</label>
    <input type="text" name="segundo_apellido"><br><br>

    <label for="tipo_identificacion">Tipo de Identificación:</label>
    <select name="tipo_identificacion">
        <option value="cc">Cédula de Ciudadanía (CC)</option>
        <option value="ce">Cédula de Extranjería (CE)</option>
        <option value="ti">Tarjeta de Identidad (TI)</option>
        <option value="pas">Pasaporte</option>
    </select><br><br>
    <label for="lugar_expedicion">Lugar de Expedición:</label>
    <input type="text" name="lugar_expedicion"><br><br>
    <label for="fecha_expedicion">Fecha de Expedición:</label>
    <input type="text" id="fecha_expedicion" name="fecha_expedicion"><br><br>
    <label for="Fecha_nacimiento">Fecha de nacimiento:</label>
    <input type="text" id="Fecha_nacimiento" name="Fecha_nacimiento"><br><br>
    <label for="Lugar_nacimiento">Lugar de nacimiento:</label>
    <input type="text" name="Lugar_nacimiento"><br><br>
    <label for="Estado_civil">Estado Civil:</label>
    <select name="Estado_civil">
        <option value="soltero">Soltero</option>
        <option value="Casado">Casado</option>
        <option value="Separado">Separado</option>
        <option value="Union Libre">Union Libre</option>
    </select><br><br>
    <label for="Direccion_residencia">Direccion de Residencia</label>
    <input type="text" id="Direccion_residencia" name="Direccion_residencia"><br><br>
    <label for="Ciudad_residencia">Ciudad de residencia:</label>
    <input type="text" id="Ciudad_residencia" name="Ciudad_residencia"><br><br>
    <label for="Telefono_fijo">Telefono fijo:</label>
    <input type="text" name="Telefono_fijo"><br><br>  
    <label for="Telefono_celular">Telefono celular:</label>
    <input type="text" name="Telefono_celular"><br><br>  


    <label for="Correo_electronico">Correo electronico:</label>
    <input type="email" name="Correo_electronico"><br><br>  
    <label for="Nombre_conyuge">Nombre Completo conyuge:</label>
    <input type="text" name="Nombre_conyuge"><br><br>  
    <label for="Tipo_identificacion_conyuge">Tipo de Identificación:</label>
    <select name="Tipo_identificacion_conyuge">
        <option value="cc">Cédula de Ciudadanía (CC)</option>
        <option value="ce">Cédula de Extranjería (CE)</option>
        <option value="ti">Tarjeta de Identidad (TI)</option>
        <option value="pas">Pasaporte</option>
    </select><br><br>
    <label for="Numero_identificacion_conyuge">Numero de identificacion:</label>
    <input type="text" name="Numero_identificacion_conyuge"><br><br>  
    <label for="Telefono_conyuge">Telefono Celular:</label>
    <input type="text" name="Telefono_conyuge"><br><br> 
    <!-- Otros campos de datos personales -->

    <hr>

    <h3>Actividad Económica</h3>

    <label for="ocupacion">Ocupación u Oficio:</label>
    <select name="ocupacion">
        <option value="ama_de_casa">Ama de Casa</option>
        <option value="empleado">Empleado</option>
        <option value="estudiante">Estudiante</option>
        <option value="independiente">Independiente</option>
    </select><br><br>

    <!-- Si el solicitante es independiente -->
    <div id="independiente_fields" style="display: none;">
        <label for="descripcion_actividad">Describa su Actividad Económica u Objeto Social:</label>
        <textarea name="descripcion_actividad"></textarea><br><br>
        <label for="direccion_oficina">Dirección de Oficina:</label>
        <input type="text" name="direccion_oficina"><br><br>
        <label for="ciudad_oficina">Ciudad de Oficina:</label>
        <input type="text" name="ciudad_oficina"><br><br>
        <label for="telefono_oficina">Teléfono de Oficina:</label>
        <input type="text" name="telefono_oficina"><br><br>
    </div>

    <!-- Si el solicitante es empleado -->
    <div id="empleado_fields" style="display: none;">
        <label for="empresa_trabajo">Empresa donde Trabaja:</label>
        <input type="text" name="empresa_trabajo"><br><br>
        <label for="nit_empresa">NIT de la Empresa:</label>
        <input type="text" name="nit_empresa"><br><br>
        <label for="direccion_empresa">Dirección de la Empresa:</label>
        <input type="text" name="direccion_empresa"><br><br>
        <label for="telefono_empresa">Teléfono de la Empresa:</label>
        <input type="text" name="telefono_empresa"><br><br>
        <label for="cargo">Cargo Actual:</label>
        <input type="text" name="cargo"><br><br>
        <label for="tipo_contrato">Tipo de Contrato:</label>
        <select name="tipo_contrato">
            <option value="fijo">Fijo</option>
            <option value="indefinido">Indefinido</option>
        </select><br><br>
        <label for="tiempo_actividad">Tiempo en la Actividad (años):</label>
        <input type="text" name="tiempo_actividad"><br><br>
    </div>

    <!-- Otros campos relacionados con la actividad económica -->

    <hr>

    <h3>Información del Codeudor o Apoderado</h3>

    <label for="Codeudor_primer_nombre">Primer Nombre:</label>
    <input type="text" name="Codeudor_primer_nombre"><br><br>

    <label for="Codeudor_segundo_nombre">Segundo Nombre:</label>
    <input type="text" name="Codeudor_segundo_nombre"><br><br>

    <label for="Codeudor_primer_apellido">Primer Apellido:</label>
    <input type="text" name="Codeudor_primer_apellido"><br><br>

    <label for="Codeudor_segundo_apellido">Segundo Apellido:</label>
    <input type="text" name="Codeudor_segundo_apellido"><br><br>
    <label for="tipo_identificacion_codeudor">Tipo de Identificación del Codeudor o Apoderado:</label>
    <select name="tipo_identificacion_codeudor">
        <option value="cc">Cédula de Ciudadanía (CC)</option>
        <option value="ce">Cédula de Extranjería (CE)</option>
        <option value="ti">Tarjeta de Identidad (TI)</option>
        <option value="pas">Pasaporte</option>
    </select><br><br>
    <label for="lugar_expedicion_codeudor">Lugar de Expedición del Codeudor o Apoderado:</label>
    <input type="text" name="lugar_expedicion_codeudor"><br><br>
    <label for="fecha_expedicion_codeudor">Fecha de Expedición del Codeudor o Apoderado:</label>
    <input type="text" name="fecha_expedicion_codeudor"><br><br>
    <label for="direccion_residencia_codeudor">Dirección de Residencia del Codeudor o Apoderado:</label>
    <input type="text" name="direccion_residencia_codeudor"><br><br>
    <label for="ciudad_residencia_codeudor">Ciudad de Residencia del Codeudor o Apoderado:</label>
    <input type="text" name="ciudad_residencia_codeudor"><br><br>
    <label for="telefono_fijo_codeudor">Teléfono Fijo del Codeudor o Apoderado:</label>
    <input type="text" name="telefono_fijo_codeudor"><br><br>
    <label for="telefono_celular_codeudor">Teléfono Celular del Codeudor o Apoderado:</label>
    <input type="text" name="telefono_celular_codeudor"><br><br>

    <!-- Otros campos de información del codeudor o apoderado -->

    <hr>

    <h3>Condiciones de Crédito</h3>

    <label for="monto_solicitado">Monto Solicitado:</label>
    <input type="text" name="monto_solicitado"><br><br>
    <label for="campana">Campaña:</label>
    <input type="text" name="campana"><br><br>
    <label for="oficina_desembolso">Oficina de Desembolso:</label>
    <input type="text" name="oficina_desembolso"><br><br>
    <label for="garantia">Garantía:</label>
    <select name="garantia">
        <option value="hipoteca">Hipoteca</option>
        <option value="vehicular">Vehicular</option>
        <option value="otros">Otros</option>
    </select><br><br>
    <label for="tipo_bien">Tipo de Bien:</label>
    <input type="text" name="tipo_bien"><br><br>
    <label for="direccion_bien">Dirección del Bien:</label>
    <input type="text" name="direccion_bien"><br><br>
    <label for="matricula">Número de Matrícula:</label>
    <input type="text" name="matricula"><br><br>
    <label for="valor_comercial">Valor Comercial:</label>
    <input type="text" name="valor_comercial"><br><br>
    <label for="hipotecado">¿Está Hipotecado?</label>
    <select name="hipotecado">
        <option value="si">Sí</option>
        <option value="no">No</option>
    </select><br><br>
    <label for="vehiculo">Vehículo:</label>
    <input type="text" name="vehiculo"><br><br>
    <label for="modelo">Modelo:</label>
    <input type="text" name="modelo"><br><br>
    <label for="placa">Placa:</label>
    <input type="text" name="placa"><br><br>
    <label for="valor_comercial_vehiculo">Valor Comercial:</label>
    <input type="text" name="valor_comercial_vehiculo"><br><br>
    <label for="pignorado">¿Está Pignorado?</label>
    <select name="pignorado">
        <option value="si">Sí</option>
        <option value="no">No</option>
    </select><br><br>

    <!-- Otros campos de condiciones de crédito -->

    <hr>

    <h3>Referencias</h3>

    <h4>Referencia 1:</h4>
    <label for="nombre_referencia1">Nombres y Apellidos:</label>
    <input type="text" name="nombre_referencia1"><br><br>
    <label for="celular_referencia1">Celular:</label>
    <input type="text" name="celular_referencia1"><br><br>
    <label for="ciudad_referencia1">Ciudad:</label>
    <input type="text" name="ciudad_referencia1"><br><br>
    <label for="departamento_referencia1">Departamento:</label>
    <input type="text" name="departamento_referencia1"><br><br>

    <h4>Referencia 2:</h4>
    <label for="nombre_referencia2">Nombres y Apellidos:</label>
    <input type="text" name="nombre_referencia2"><br><br>
    <label for="celular_referencia2">Celular:</label>
    <input type="text" name="celular_referencia2"><br><br>
    <label for="ciudad_referencia2">Ciudad:</label>
    <input type="text" name="ciudad_referencia2"><br><br>
    <label for="departamento_referencia2">Departamento:</label>
    <input type="text" name="departamento_referencia2"><br><br>

    <input type="submit" value="Enviar">

</form>

<script>
    // Mostrar campos adicionales dependiendo de la ocupación seleccionada
    document.querySelector('select[name="ocupacion"]').addEventListener('change', function() {
        var selectedOption = this.value;
        if (selectedOption === 'independiente') {
            document.getElementById('independiente_fields').style.display = 'block';
            document.getElementById('empleado_fields').style.display = 'none';
        } else if (selectedOption === 'empleado') {
            document.getElementById('empleado_fields').style.display = 'block';
            document.getElementById('independiente_fields').style.display = 'none';
        } else {
            document.getElementById('independiente_fields').style.display = 'none';
            document.getElementById('empleado_fields').style.display = 'none';
        }
    });
</script>

</body>
</html>
