<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Solicitud de Crédito</title>
    <link rel="stylesheet" type="text/css" href="style2.css">

</head>
<body>

<form action="procesar_formulario.php" method="POST">
    <h2>Formulario de Solicitud de Crédito</h2>

    <div class="input-group">
        <label for="fecha">Fecha:</label>
        <input type="text" name="fecha" value="<?php echo date('Y-m-d'); ?>" readonly>

        <label for="ciudad_solicitud">Ciudad de Solicitud:</label>
        <input type="text" name="ciudad_solicitud">

        <label for="solicitante">Solicitante:</label>
        <select name="solicitante">
            <option value="cliente">Cliente</option>
            <option value="cliente_firma">Cliente con Firma a Ruego</option>
            <option value="apoderado">Cliente con Apoderado</option>
        </select>
    </div><br>

    <div class="input-group">
        <label for="solicitud_credito">Solicitud de Crédito:</label>
        <select name="solicitud_credito">
            <option value="educativo">Educativo</option>
            <option value="renovacion">Renovación</option>
            <option value="otro">Otro</option>
        </select>

        <label>Datos Personales del Solicitante:</label>

        <label for="primer_nombre">Primer Nombre:</label>
        <input type="text" name="primer_nombre">
    </div><br>

    <div class="input-group">
        <label for="segundo_nombre">Segundo Nombre:</label>
        <input type="text" name="segundo_nombre">

        <label for="primer_apellido">Primer Apellido:</label>
        <input type="text" name="primer_apellido">

        <label for="segundo_apellido">Segundo Apellido:</label>
        <input type="text" name="segundo_apellido">
    </div><br>

    <!-- Otros campos de datos personales -->

    <!-- ... -->

    <input type="submit" value="Enviar">

</form>

<script>
    // Mostrar campos adicionales dependiendo de la ocupación seleccionada
    document.querySelector('select[name="ocupacion"]').addEventListener('change', function() {
        var selectedOption = this.value;
        if (selectedOption === 'independiente') {
            document.getElementById('independiente_fields').style.display = 'block';
            document.getElementById('empleado_fields').style.display = 'none';
        } else if (selectedOption === 'empleado') {
            document.getElementById('empleado_fields').style.display = 'block';
            document.getElementById('independiente_fields').style.display = 'none';
        } else {
            document.getElementById('independiente_fields').style.display = 'none';
            document.getElementById('empleado_fields').style.display = 'none';
        }
    });
</script>

</body>
</html>
